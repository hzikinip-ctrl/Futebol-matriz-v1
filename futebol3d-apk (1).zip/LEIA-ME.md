# Futebol 3D -> APK
1. Crie um repositório no GitHub (github.com/new) e envie o conteúdo desta pasta (incluindo .github).
2. Abra a aba Actions > "Build APK" > aguarde ~5 min.
3. Baixe o artefato "futebol3d-apk" (app-debug.apk) e instale no celular
   (permita "instalar apps de fontes desconhecidas").
